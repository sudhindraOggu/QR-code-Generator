CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    storage_path VARCHAR(255),
    qr_code_data TEXT,
    qr_code_path VARCHAR(255)
);
