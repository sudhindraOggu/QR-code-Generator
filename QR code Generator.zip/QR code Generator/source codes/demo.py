import tkinter as tk
import shutil 
from tkinter import messagebox, filedialog
import qrcode
from PIL import Image, ImageTk
from dropbox.files import WriteMode
import time
import os
import mysql.connector
import dropbox
from dropbox.exceptions import AuthError
import webbrowser
import urllib.parse  # For URL encoding

DROPBOX_ACCESS_TOKEN = 'sl.CBVLA33Cu_34nAxzq7BaoPIKc9ccIH0yrQNosBN_FZbNEEBqGRSZ4-Wa8b4adGELKkslN1wGRhXFP9-JY7DyZAcoAZMggCcNk6D6vX3rwIifqrBrhq0hDB6pYyrxKB-LOs9orPXSbUW2unM'  # Put your Dropbox access token here
dbx = dropbox.Dropbox(DROPBOX_ACCESS_TOKEN)
def connect_db():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",  # replace with your MySQL username
            password="Jyothi25",  # replace with your MySQL password
            database="qr_project"  # replace with your database name
        )
        return conn
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")
        return None

# Login function
def login():
    conn = connect_db()
    if not conn:
        return
    
    username = username_entry.get()
    password = password_entry.get()

    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
    result = cursor.fetchone()

    if result:
        messagebox.showinfo("Login Success", f"Welcome, {username}!")
        show_frame(home_frame)
        show_subframe(text_qr_frame)  # Default to show text QR frame on login
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")

    conn.close()
DEFAULT_STORAGE_PARENT_FOLDER = r"C:\Users\ondsh\OneDrive\Desktop\miniProject\QR code Generator\usersProfile"

def create_profile():
    conn = connect_db()
    if not conn:
        return

    username = username_entry_create.get()
    password = password_entry_create.get()

    # Ensure the parent folder exists
    os.makedirs(DEFAULT_STORAGE_PARENT_FOLDER, exist_ok=True)

    # Generate user-specific folder inside the default parent folder
    storage_path = os.path.join(DEFAULT_STORAGE_PARENT_FOLDER, username)

    # Validate username and password input
    if not username or not password:
        messagebox.showerror("Error", "Username and password are required!")
        return

    try:
        # Create the user-specific folder
        os.makedirs(storage_path, exist_ok=True)

        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (username, password, storage_path) VALUES (%s, %s, %s)", 
            (username, password, storage_path)
        )
        conn.commit()
        messagebox.showinfo(
            "Profile Created", 
            f"Profile created for {username}! QR codes will be stored in:\n{storage_path}"
        )
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"Could not create profile: {err}")
    except Exception as e:
        messagebox.showerror("Error", f"Could not create storage folder: {e}")
    finally:
        conn.close()

# Add separate label variables for each QR code display
# text_qr_code_label = None
# # image_qr_code_label = None

# List to store references to the QR code labels
qr_code_labels = []

def generate_text_qr():
    global qr_img_path  # Make qr_img_path a global variable
    text = text_area.get("1.0", tk.END).strip()
    if not text:
        messagebox.showwarning("Input Required", "Please enter some text to generate QR code.")
        return

    # Generate QR code image
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(text)
    qr.make(fit=True)
    qr_img = qr.make_image(fill="black", back_color="white")

    # Save and display the QR code image
    qr_img_path = "temp_qr.png"  # Temporary path to save the QR code before displaying
    qr_img.save(qr_img_path)
    
    qr_img_display = Image.open(qr_img_path)
    qr_img_display = qr_img_display.resize((150, 150), Image.LANCZOS)

    # Create a new label for each generated QR code
    qr_img_display = ImageTk.PhotoImage(qr_img_display)
    
    # Create a new label and pack it into the text_qr_frame
    new_qr_code_label = tk.Label(text_qr_frame, image=qr_img_display, bg="#f0f0f0")
    new_qr_code_label.image = qr_img_display  # Keep a reference
    new_qr_code_label.pack(pady=(10, 5))
    
    # Store the reference to the new label
    qr_code_labels.append(new_qr_code_label)

def upload_image_to_dropbox(image_path):
    """Uploads an image to Dropbox and returns the shared link."""
    file_name = os.path.basename(image_path)

    # Upload the image to Dropbox
    with open(image_path, "rb") as f:
        dbx.files_upload(f.read(), "/" + file_name)

    try:
        # Attempt to create a shared link for the uploaded file
        shared_link_metadata = dbx.sharing_create_shared_link_with_settings("/" + file_name)
    except dropbox.exceptions.ApiError as e:
        # Check if the error is because the link already exists
        if e.error.is_shared_link_already_exists():
            # If it exists, retrieve the existing shared link
            shared_link_metadata = dbx.sharing_get_shared_link_metadata("/" + file_name)
        else:
            # Re-raise the exception if it's not the expected error
            raise

    return shared_link_metadata.url

def generate_image_qr():
    image_path = filedialog.askopenfilename(title="Select an Image", filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.gif")])
    if not image_path:
        return

    try:
        # Upload the image to Dropbox and get the URL
        shared_url = upload_image_to_dropbox(image_path)

        # Generate QR code for the shared URL
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(shared_url)
        qr.make(fit=True)
        qr_img = qr.make_image(fill="black", back_color="white")

        # Save and display the QR code image
        global qr_img_path  # Make qr_img_path a global variable
        qr_img_path = "temp_qr_image.png"  # Temporary path to save the QR code before displaying
        qr_img.save(qr_img_path)

        qr_img_display = Image.open(qr_img_path)
        qr_img_display = qr_img_display.resize((150, 150), Image.LANCZOS)

        # Update the displayed QR code in the image QR frame
        qr_img_display = ImageTk.PhotoImage(qr_img_display)

        # If image_qr_code_label does not exist, create it
        global image_qr_code_label
        if image_qr_code_label is None:
            image_qr_code_label = tk.Label(image_qr_frame, bg="#f0f0f0")
            image_qr_code_label.pack(pady=(10, 5))
        
        image_qr_code_label.config(image=qr_img_display)
        image_qr_code_label.image = qr_img_display  # Keep a reference

        messagebox.showinfo("Image Uploaded", f"Image uploaded to Dropbox. QR code generated for:\n{shared_url}")

    except Exception as e:
        messagebox.showerror("Upload Error", f"Error uploading image to Dropbox: {e}")

# Ensure you have a reference to the label for displaying the QR code
image_qr_code_label = None  # Initialize the label reference

# Ensure you call show_frame and show_subframe appropriately in your GUI setup

def save_image_qr_code():
    conn = connect_db()
    if not conn:
        return

    # Check if QR code was generated
    if 'qr_img_path' not in globals() or not os.path.exists(qr_img_path):
        messagebox.showwarning("No QR Code", "Please generate a QR code first.")
        return
    
    username = username_entry.get()
    qr_code_name = qr_code_name_entry.get().strip()  # Get the entered QR code name

    if not qr_code_name:
        messagebox.showwarning("Invalid Name", "Please enter a name for the QR code before saving.")
        return
    
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT storage_path FROM users WHERE username=%s", (username,))
        result = cursor.fetchone()

        if result:
            storage_path = result[0]
            if not storage_path or not os.path.isdir(storage_path):
                messagebox.showwarning("Invalid Path", "Please specify a valid storage path in your profile.")
                return
            
            # Ensure the name has no forbidden characters and set up the final path
            qr_code_name = "".join(c for c in qr_code_name if c.isalnum() or c in "._-")
            qr_img_final_path = os.path.join(storage_path, f"{qr_code_name}.png")
            
            # Move the QR code to the user's specified storage path
            shutil.move(qr_img_path, qr_img_final_path)
            messagebox.showinfo("Saved", f"QR Code saved to {qr_img_final_path}!")
        
        else:
            messagebox.showwarning("User Not Found", "User profile not found. Please create a profile.")
    
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error retrieving storage path: {err}")
    
    except Exception as e:
        messagebox.showerror("File Error", f"Error saving QR code: {e}")
    
    finally:
        conn.close()

def generate_file_qr():
    # Open file dialog to select a file
    file_path = filedialog.askopenfilename(title="Select a File", filetypes=[("All Files", "*.*")])
    
    if not file_path:
        return  # If no file is selected, exit the function

    try:
        # Upload file to Dropbox and get shared link
        shared_link = upload_file_to_dropbox(file_path)
        if not shared_link:
            return

        # Generate QR code for the shared link
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(shared_link)
        qr.make(fit=True)
        qr_img = qr.make_image(fill="black", back_color="white")

        # Save the QR code image
        global qr_img_path  # Make qr_img_path a global variable for saving and sharing later
        qr_img_path = "file_qr_code.png"
        qr_img.save(qr_img_path)

        # Display the QR code on the GUI
        qr_img_display = Image.open(qr_img_path)
        qr_img_display = qr_img_display.resize((150, 150), Image.LANCZOS)
        qr_img_display = ImageTk.PhotoImage(qr_img_display)

        # Ensure the file_qr_code_label exists and update it
        global file_qr_code_label
        if file_qr_code_label is None:
            file_qr_code_label = tk.Label(file_qr_frame, bg="#f0f0f0")
            file_qr_code_label.pack(pady=(10, 5))

        file_qr_code_label.config(image=qr_img_display)  # Display QR code
        file_qr_code_label.image = qr_img_display  # Keep reference to prevent garbage collection

        messagebox.showinfo("QR Code Generated", "QR code generated successfully!")

        # Now call the share function with the generated file path and data
        tk.Button(file_qr_frame, text="Share QR Code", 
                  command=lambda: share_qr_code("file", data_path=file_path), 
                  bg="#4CAF50", fg="white").pack(pady=(10, 5))

    except Exception as e:
        messagebox.showerror("Error", f"Error generating QR code: {str(e)}")



def upload_file_to_dropbox(file_path):
    try:
        # Open the file and upload it to Dropbox
        with open(file_path, 'rb') as f:
            # Upload the file to the root folder
            dropbox_path = '/' + os.path.basename(file_path)
            dbx.files_upload(f.read(), dropbox_path, mode=dropbox.files.WriteMode.overwrite)
            
        # Get the shared link for the file
        shared_link_metadata = dbx.sharing_create_shared_link_with_settings(dropbox_path)
        shared_link = shared_link_metadata.url
        return shared_link
    except Exception as e:
        messagebox.showerror("Error", f"Error uploading to Dropbox: {str(e)}")
        return None
    except Exception as e:
        # Handle errors during upload
        messagebox.showerror("Upload Failed", f"Error uploading file: {str(e)}")

def save_file_qr_code():
    try:
        qr_img_path = "file_qr_code.png"
        file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG Files", "*.png")])
        if file_path:
            # Save the generated QR code image to the selected path
            qr_img = Image.open(qr_img_path)
            qr_img.save(file_path)
            messagebox.showinfo("Saved", f"QR code saved as {file_path}")
    except Exception as e:
        messagebox.showerror("Error", f"Error saving QR code: {str(e)}")



def save_qr_code():
    conn = connect_db()
    if not conn:
        return

    # Check if QR code was generated
    if 'qr_img_path' not in globals() or not os.path.exists(qr_img_path):
        messagebox.showwarning("No QR Code", "Please generate a QR code first.")
        return
    
    username = username_entry.get()
    qr_code_name = qr_code_text.get("1.0", tk.END).strip()
    

    try:
        cursor = conn.cursor()
        cursor.execute("SELECT storage_path FROM users WHERE username=%s", (username,))
        result = cursor.fetchone()

        if result:
            storage_path = result[0]
            if not storage_path or not os.path.isdir(storage_path):
                messagebox.showwarning("Invalid Path", "Please specify a valid storage path in your profile.")
                return
            
            # Set up the final path for saving the QR code
            qr_img_final_path = os.path.join(storage_path,f"{qr_code_name}.png")
            
            # Move the QR code to the user's specified storage path
            shutil.move(qr_img_path, qr_img_final_path)
            messagebox.showinfo("Saved", f"QR Code saved to {qr_img_final_path}!")
        
        else:
            messagebox.showwarning("User Not Found", "User profile not found. Please create a profile.")
    
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error retrieving storage path: {err}")
    
    except Exception as e:
        messagebox.showerror("File Error", f"Error saving QR code: {e}")
    
    finally:
        conn.close()

def share_qr_code(type, data_path=None):
    # Ensure a valid QR code exists
    if 'qr_img_path' not in globals() or not os.path.exists(qr_img_path):
        messagebox.showwarning("No QR Code", "Please generate a QR code first.")
        return

    # Generate a unique file name for the QR code
    file_name = generate_unique_file_name(f"{type}_QR_Code")
    dropbox_path = f"/YourFolder/{file_name}"

    # Dropbox Access Token (Use environment variable or securely store it)
    ACCESS_TOKEN = "sl.CBVLA33Cu_34nAxzq7BaoPIKc9ccIH0yrQNosBN_FZbNEEBqGRSZ4-Wa8b4adGELKkslN1wGRhXFP9-JY7DyZAcoAZMggCcNk6D6vX3rwIifqrBrhq0hDB6pYyrxKB-LOs9orPXSbUW2unM"

    try:
        # Initialize Dropbox client
        dbx = dropbox.Dropbox(ACCESS_TOKEN)

        # Upload the QR code image to Dropbox
        with open(qr_img_path, "rb") as f:
            dbx.files_upload(f.read(), dropbox_path, mode=dropbox.files.WriteMode("add"))

        # Generate a sharable link
        shared_link_metadata = dbx.sharing_create_shared_link_with_settings(dropbox_path)
        shared_url = shared_link_metadata.url

        # Modify the URL for direct access (optional)
        if "dl=0" in shared_url:
            shared_url = shared_url.replace("dl=0", "raw=1")

        # Prepare the sharing message
        if type == "file" and data_path:
            share_message = f"Check out this QR code for your file: {shared_url}\nFile Path: {data_path}"
        elif type == "image":
            share_message = f"Check out this QR code image: {shared_url}"
        else:
            messagebox.showerror("Invalid Type", "Unsupported QR code type specified.")
            return

        # Construct WhatsApp sharing link
        whatsapp_url = f"https://wa.me/?text={share_message}"

        # Open the WhatsApp sharing link in the default browser
        webbrowser.open(whatsapp_url)

        # Show success message
        messagebox.showinfo("Success", "QR Code shared successfully via WhatsApp!")

    except dropbox.exceptions.ApiError as e:
        messagebox.showerror("Dropbox Sharing Error", f"Error sharing QR code: {e}")
    except Exception as e:
        messagebox.showerror("Unexpected Error", f"An unexpected error occurred: {e}")


def generate_unique_file_name(base_name):
    import time
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    return f"{base_name}_{timestamp}.png"


def show_frame(frame):
    frame.tkraise()

def show_subframe(subframe):
    subframe.tkraise()

# GUI Setup
root = tk.Tk()
root.geometry("600x500")
root.title("QR Code Generator App")
root.config(bg="#f0f0f0")  # Background color

# Main frames for login, create profile, and home
login_frame = tk.Frame(root, bg="#f0f0f0")
create_profile_frame = tk.Frame(root, bg="#f0f0f0")
home_frame = tk.Frame(root, bg="#f0f0f0")

# Home sub-frames for different QR code options
text_qr_frame = tk.Frame(home_frame, bg="#f0f0f0")
image_qr_frame = tk.Frame(home_frame, bg="#f0f0f0")
file_qr_frame = tk.Frame(home_frame, bg="#f0f0f0")

for frame in (login_frame, create_profile_frame, home_frame):
    frame.grid(row=1, column=0, sticky="nsew")

for subframe in (text_qr_frame, image_qr_frame, file_qr_frame):
    subframe.grid(row=1, column=0, sticky="nsew")

# Configure grid weight to allow resizing
root.grid_rowconfigure(1, weight=1)
root.grid_columnconfigure(0, weight=1)
home_frame.grid_rowconfigure(1, weight=1)
home_frame.grid_columnconfigure(0, weight=1)

# --- Login Page --- 
tk.Label(login_frame, text="Login", font=("Arial", 24), bg="#f0f0f0", fg="#333").pack(pady=(20, 10))
tk.Label(login_frame, text="Username:", bg="#f0f0f0").pack(pady=(10, 0))

username_entry = tk.Entry(login_frame, width=30)
username_entry.pack(pady=(0, 10))
tk.Label(login_frame, text="Password:", bg="#f0f0f0").pack(pady=(10, 0))
password_entry = tk.Entry(login_frame, show="*", width=30)
password_entry.pack(pady=(0, 20))
tk.Button(login_frame, text="Login", command=login, bg="#4CAF50", fg="white", width=15).pack(pady=(10, 5))
tk.Button(login_frame, text="Create Profile", command=lambda: show_frame(create_profile_frame)).pack(pady=(15, 5))

# --- Create Profile Page --- 
tk.Label(create_profile_frame, text="Create New Profile", font=("Arial", 24), bg="#f0f0f0", fg="#333").pack(pady=(20, 10))
tk.Label(create_profile_frame, text="New Username:", bg="#f0f0f0").pack(pady=(10, 0))
username_entry_create = tk.Entry(create_profile_frame, width=30)
username_entry_create.pack(pady=(0, 10))
tk.Label(create_profile_frame, text="New Password:", bg="#f0f0f0").pack(pady=(10, 0))
password_entry_create = tk.Entry(create_profile_frame, show="*", width=30)
password_entry_create.pack(pady=(0, 20))
tk.Button(create_profile_frame, text="Create Profile", command=create_profile, bg="#4CAF50", fg="white", width=15).pack(pady=(10, 5))
tk.Button(create_profile_frame, text="Back to Login", command=lambda: show_frame(login_frame), bg="#FF5722", fg="white", width=15).pack(pady=(5, 20))
# Button to browse for the directory

# --- Home Page and Navbar --- 
navbar_frame = tk.Frame(home_frame, bg="#2196F3")
navbar_frame.grid(row=0, column=0, sticky="ew")  # Place navbar at the top of home frame

# Nav buttons that control which subframe is displayed
tk.Button(navbar_frame, text="Generate Text QR", command=lambda: show_subframe(text_qr_frame), bg="#4CAF50", fg="white").pack(side=tk.LEFT, padx=5, pady=5)
tk.Button(navbar_frame, text="Generate Image QR", command=lambda: show_subframe(image_qr_frame), bg="#4CAF50", fg="white").pack(side=tk.LEFT, padx=5, pady=5)
tk.Button(navbar_frame, text="Generate File QR", command=lambda: show_subframe(file_qr_frame), bg="#4CAF50", fg="white").pack(side=tk.LEFT, padx=5, pady=5)

# Text QR Frame
tk.Label(text_qr_frame, text="Enter Text to Generate QR Code:", bg="#f0f0f0").pack(pady=(10, 5))
text_area = tk.Text(text_qr_frame, height=5, width=50)
text_area.pack(pady=(0, 10))
tk.Button(text_qr_frame, text="Generate QR Code", command=generate_text_qr, bg="#4CAF50", fg="white").pack(pady=(10, 5))

qr_code_label = tk.Label(text_qr_frame, bg="#f0f0f0")
qr_code_label.pack(pady=(10, 5))

qr_name_label=tk.Label(text_qr_frame,text="Enter Name for QR Code:",bg="#f0f0f0").pack(pady=(10,5))
qr_code_text=tk.Text(text_qr_frame,height=1,width=6)
qr_code_text.pack(pady=(0,5))
# save button
tk.Button(text_qr_frame, text="Save QR Code", command=save_qr_code, bg="#4CAF50", fg="white").pack(pady=(10, 5))


# --- Image QR Frame ---
tk.Label(image_qr_frame, text="Upload an Image to Generate QR Code:", bg="#f0f0f0").pack(pady=(10, 5))

# Entry to display the selected image path
image_path_entry = tk.Entry(image_qr_frame, width=50)
image_path_entry.pack(pady=(0, 10))

# Function to browse for an image file
# Button to generate QR code for the image
tk.Button(image_qr_frame, text="Browse & Generate QR Code", command=generate_image_qr, bg="#4CAF50", fg="white").pack(pady=(10, 5))

# Label to display the generated QR code
qr_code_label = tk.Label(image_qr_frame, bg="#f0f0f0")
qr_code_label.pack(pady=(10, 5))

tk.Label(image_qr_frame, text="Enter Name for QR Code:", bg="#f0f0f0").pack(pady=(10, 5))

# Entry field for the QR code name
qr_code_name_entry = tk.Entry(image_qr_frame, width=50)
qr_code_name_entry.pack(pady=(0, 10))

# Save button for the generated QR code
save_image_qr_button = tk.Button(image_qr_frame, text="Save Image QR Code", command=save_image_qr_code)
save_image_qr_button.pack(pady=5)

# Share button for the image QR code
tk.Button(image_qr_frame, text="Share QR Code", 
          command=lambda: share_qr_code("image", data_path=image_path_entry.get()), 
          bg="#4CAF50", fg="white").pack(pady=(10, 5))

#FILE FRAME
tk.Label(file_qr_frame, text="Upload a File to Generate QR Code:", bg="#f0f0f0").pack(pady=(10, 5))

# Entry to display the selected file path
file_path_entry = tk.Entry(file_qr_frame, width=50)
file_path_entry.pack(pady=(0, 10))


# Button to generate QR code for the file
tk.Button(file_qr_frame, text="Generate QR Code", command=generate_file_qr, bg="#4CAF50", fg="white").pack(pady=(10, 5))

# Label to display the generated QR code
file_qr_code_label = tk.Label(file_qr_frame, bg="#f0f0f0")
file_qr_code_label.pack(pady=(10, 5))

# Save button for the generated QR code
save_file_qr_button = tk.Button(file_qr_frame, text="Save File QR Code", command=save_file_qr_code)
save_file_qr_button.pack(pady=5)

# Show the login frame first
show_frame(login_frame)  
root.mainloop()


